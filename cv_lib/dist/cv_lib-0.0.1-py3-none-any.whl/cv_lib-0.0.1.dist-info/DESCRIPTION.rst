A library for computer vision


