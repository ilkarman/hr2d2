# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from cv_lib.azureml_tools.workspace import workspace_for_user
from cv_lib.azureml_tools.experiment import PyTorchExperiment
