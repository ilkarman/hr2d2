# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

__version__ = "0.0.1"
